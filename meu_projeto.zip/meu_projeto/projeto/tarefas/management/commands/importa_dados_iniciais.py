import csv
from django.core.management.base import BaseCommand
from tarefas.models import Projeto, Tarefa
from datetime import datetime

class Command(BaseCommand):
    help = 'Importa dados iniciais de Projetos e Tarefas de um arquivo CSV'

    def add_arguments(self, parser):
        
        parser.add_argument(
            'base_csv', 
            type=str, 
            help='Caminho para o arquivo CSV contendo os dados iniciais'
        )

    def handle(self, *args, **kwargs):
        
        csv_file_path = kwargs['base_csv']
        
        try:
            
            with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                
                self.stdout.write(self.style.NOTICE(f'Iniciando importação do arquivo: {csv_file_path}'))
                
                for row in reader:
                
                    nome_projeto = row['nome_projeto']
                    projeto, created_projeto = Projeto.objects.get_or_create(
                        nome=nome_projeto,
                        defaults={
                            'descricao': row['descricao_projeto']
                           
                        }
                    )

                    if created_projeto:
                        self.stdout.write(self.style.SUCCESS(f'Projeto criado: {nome_projeto}'))

                    
                    data_limite_str = row.get('data_limite')
                    data_limite = None
                    if data_limite_str:
                        
                        data_limite = datetime.strptime(data_limite_str, '%Y-%m-%d').date()

                    Tarefa.objects.create(
                        titulo=row['titulo_tarefa'],
                        status=row['status'],
                        prioridade=row['prioridade'],
                        data_limite=data_limite,
                        projeto=projeto 
                    )
                
                self.stdout.write(self.style.SUCCESS('\nImportação concluída com sucesso!'))
                
        except FileNotFoundError:
            self.stdout.write(self.style.ERROR(f'Erro: Arquivo não encontrado no caminho: {csv_file_path}'))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Ocorreu um erro durante a importação: {e}'))
